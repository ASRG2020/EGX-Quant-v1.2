import pandas as pd
from app.backtest.engine import run_backtest

def test_backtest_no_lookahead():
    n=50; close=pd.Series(range(100,100+n),dtype=float)
    df=pd.DataFrame({"date":pd.date_range("2025-01-01",periods=n),"close":close,"signal":[1]*n})
    result=run_backtest(df)
    assert result["final_capital"]>result["initial_capital"]
    assert "alpha" in result
