from dataclasses import dataclass
import pandas as pd
from app.backtest.metrics import performance_metrics

@dataclass
class BacktestConfig:
    initial_capital: float=100000.0
    transaction_cost: float=0.001
    slippage: float=0.0005

def run_backtest(df: pd.DataFrame, config: BacktestConfig|None=None) -> dict:
    config=config or BacktestConfig()
    if df.empty: return {"initial_capital":config.initial_capital,"final_capital":config.initial_capital,"strategy":performance_metrics(pd.Series(dtype=float)),"benchmark":performance_metrics(pd.Series(dtype=float)),"alpha":0.0,"trades":0}
    if not {"date","close","signal"}.issubset(df.columns): raise ValueError("date, close and signal are required")
    d=df.sort_values("date").reset_index(drop=True).copy()
    d["market_return"]=d.close.pct_change().fillna(0)
    d["position"]=d.signal.shift(1).fillna(0).clip(0,1)
    d["turnover"]=d.position.diff().abs().fillna(d.position.abs())
    d["strategy_return"]=d.position*d.market_return-d.turnover*(config.transaction_cost+config.slippage)
    d["benchmark_return"]=d.market_return
    d["equity"]=config.initial_capital*(1+d.strategy_return).cumprod()
    strat=performance_metrics(d.strategy_return); bench=performance_metrics(d.benchmark_return)
    alpha=float(strat["annualized_return"]-bench["annualized_return"])
    return {"initial_capital":config.initial_capital,"final_capital":float(d.equity.iloc[-1]),"strategy":strat,"benchmark":bench,"alpha":alpha,"trades":int((d.turnover>0).sum())}
