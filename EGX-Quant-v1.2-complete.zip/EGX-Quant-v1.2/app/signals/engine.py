import pandas as pd

def score_signal(df: pd.DataFrame) -> dict:
    if df.empty: return {"action":"HOLD","score":0.0,"confidence":0.0,"reasons":[]}
    r = df.iloc[-1]; score = 0.0; reasons=[]
    if pd.notna(r.get("sma20")):
        score += 1 if r.close > r.sma20 else -1; reasons.append("trend_sma20")
    if pd.notna(r.get("sma50")):
        score += 1 if r.close > r.sma50 else -1; reasons.append("trend_sma50")
    if pd.notna(r.get("macd")) and pd.notna(r.get("macd_signal")):
        score += 1 if r.macd > r.macd_signal else -1; reasons.append("macd")
    if pd.notna(r.get("rsi14")):
        if r.rsi14 < 35: score += 1; reasons.append("rsi_oversold")
        elif r.rsi14 > 70: score -= 1; reasons.append("rsi_overbought")
    if pd.notna(r.get("momentum20")):
        score += 0.5 if r.momentum20 > 0 else -0.5; reasons.append("momentum20")
    if pd.notna(r.get("volume_ratio")) and r.volume_ratio > 1.2: reasons.append("volume_confirmation")
    confidence = min(1.0, abs(score)/4.5)
    action = "BUY" if score >= 2 else "SELL" if score <= -2 else "HOLD"
    return {"action": action, "score": round(float(score),3), "confidence": round(float(confidence),3), "reasons": reasons}
